package com.example.demo.Product;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;

@Service
public class ProductService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<Product> getAllProduct()
    {
        String sql = "select * from product";
        return this.jdbcTemplate.query(sql, BeanPropertyRowMapper.newInstance(Product.class));
    }

    public Product getProductById(Long pid)
    {
        String sql = "select * from product where pid = ?";
        return this.jdbcTemplate.queryForObject(sql, BeanPropertyRowMapper.newInstance(Product.class), pid);
    }

    public List<Product> getAllProductByCatOrderByDate(Long catid)
    {
        String sql = "select * from product where catid = ? order by adddate desc";
        return this.jdbcTemplate.query(sql, BeanPropertyRowMapper.newInstance(Product.class), catid);
    }
}
