package com.example.demo.Customer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/customer")
public class CustomerController {
    @Autowired
    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @GetMapping("/")
    public List<Customer> getAllCustomer()
    {
        return this.customerService.getAllCustomer();
    }

    @GetMapping("/{email}")
    public Customer findCustomerByEmail(@PathVariable(name = "email") String email)
    {
        return this.customerService.getCustomerByEmail(email);
    }

    @PostMapping("/add")
    public String addNewCustomer(@RequestBody Customer customer)
    {
        if(this.customerService.addNewCustomer(customer) == 1)
        {
            return "done";
        }
        else return "undone";
    }

    @PutMapping("/update/{email}")
    public String updateByEmail(@RequestBody Customer customer, @PathVariable(name = "email") String email)
    {
        if(this.customerService.updateByEmail(customer) == 0)
        {
            return "failed";
        }
        else
        {
            return "done";
        }
    }

    @PutMapping("/changepassword/{email}")
    public String changePassword(@RequestBody Customer customer)
    {
        try
        {
            if(this.customerService.updatePassByEmail(customer) == 1)
            {
                return "done";
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return "undone";
    }

    @GetMapping("/login")
    public String login(@RequestBody Customer customer)
    {
        if(this.customerService.login(customer))
            return "done";
        return "undone";
    }
}
