package com.example.demo.Product;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/product")
public class ProductController {
    @Autowired
    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping("/")
    public List<Product> getAllProduct()
    {
        return this.productService.getAllProduct();
    }

    @GetMapping("/{pid}")
    public Product getProductById(@PathVariable(name = "pid") Long pid)
    {
        return this.productService.getProductById(pid);
    }

    @GetMapping("/category/{catid}")
    public List<Product> getProductByCatOrderByDate(@PathVariable(name = "catid") Long catId)
    {
        return this.productService.getAllProductByCatOrderByDate(catId);
    }
}
