package com.example.demo.Customer;

import com.example.demo.DemoApplication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Service
public class CustomerService implements UserDetailsService {

    @Autowired
    private JdbcTemplate jdbcTemplate;
    private DemoApplication.CustomPasswordEncoder customPasswordEncoder;

    @Autowired
    public CustomerService(@Lazy DemoApplication.CustomPasswordEncoder customPasswordEncoder) {
        this.customPasswordEncoder = customPasswordEncoder;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Customer customer = new Customer();
        return new org.springframework.security.core.userdetails.User(customer.getEmail(), customer.getPass(), Collections.emptyList());
    }

    public List<Customer> getAllCustomer()
    {
        String sql = "select * from customer";
        List<Customer> customerList = this.jdbcTemplate.query(sql, BeanPropertyRowMapper.newInstance(Customer.class));
        for(Customer customer : customerList)
        {
            customer.setPass("hidden pass");
        }
        return customerList;
    }

    public Customer getCustomerByEmail(String email)
    {
        String sql = "select * from customer where email = ?";
        Customer customer = this.jdbcTemplate.queryForObject(sql, BeanPropertyRowMapper.newInstance(Customer.class), email);
        return customer;
    }

    public int existByEmail(String email)
    {
        String sql = "select count(*) from customer where email = ?";
        return this.jdbcTemplate.queryForObject(sql, int.class, email);
    }

    public int addNewCustomer(Customer customer)
    {
        customer.setPass(this.customPasswordEncoder.encode(customer.getPass()));
        String sql = "insert into customer values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        int res;
        if(existByEmail(customer.getEmail()) == 1)
        {
            res = 0;
        }
        else res = this.jdbcTemplate.update(sql, customer.toArray());
        return res;
    }
    public int updateByEmail(Customer customer)
    {
        String sql = "update customer set name = ?, dob = ?, gender = ?, phone = ?, address = ?, district = ?, city = ?, active = ? where email = ?";
        return this.jdbcTemplate.update(sql, customer.toArrayForUpdate());
    }
    public int updatePassByEmail(Customer customer)
    {
        int res;
        String sql = "update customer set pass = ? where email = ?";
        customer.setPass(this.customPasswordEncoder.encode(customer.getPass()));
        res = this.jdbcTemplate.update(sql, customer.toArrayForPasswordChange());
        return res;
    }

    public boolean comparePassword(Customer customer)
    {
        Customer storedCustomer = getCustomerByEmail(customer.getEmail());
        return this.customPasswordEncoder.matches(customer.getPass(), storedCustomer.getPass());
    }

    public boolean login(Customer customer)
    {
        boolean res = true;
        if(existByEmail(customer.getEmail()) == 0)
        {
            res = true;
        }
        if(!comparePassword(customer))
        {
            res = true;
        }
        return res;
    }
}
