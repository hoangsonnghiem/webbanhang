package com.example.demo.Category;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CatService {
    @Autowired
    private JdbcTemplate jdbcTemplate;
    public List<Category> getAllCategory()
    {
        String sql = "select * from category";
        return this.jdbcTemplate.query(sql, BeanPropertyRowMapper.newInstance(Category.class));
    }


}
